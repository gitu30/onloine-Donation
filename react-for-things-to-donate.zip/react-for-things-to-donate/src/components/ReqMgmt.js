import React, { Component } from 'react';


 class FetchData extends React.Component {
  static displayName = FetchData.name;

  constructor (props) {
    super(props);
    this.state = { receiver_req: [], loading: true };
    this.f1 = this.f1.bind(this);
  }

  componentDidMount=()=>{
    const url="http://localhost:8080/getFromrequeststatus";

    fetch(url)
    .then(response => response.json())
    .then(data => {
      this.setState({ receiver_req : data, loading: false });
    });
  }
   
  f1=(e,reqid)=>{
     alert("in fun");
     alert(reqid);
      fetch("http://localhost:8080/approve?reqid="+reqid)
      .then(resp => {
        if(resp.status === 200)
        {
          alert("approved success");
        }
      })
    }

    f2=(e,reqid)=>{
      fetch("http://localhost:8080/reject?reqid="+reqid)
      .then(resp => {
        if(resp.status === 200)
        {
          alert("rejected success");
        }
      })
    }
        

    
    render=()=>
    {
    return (
      <table className='table table-border'>
         <thead className="thead-dark">  
                    <tr>  
                        <th scope="col">Request ID</th>  
                        <th scope="col">Name</th>  
                        <th scope="col">UniqueId</th>
                        <th scope="col">Email</th>
                        <th scope="col">Address</th>  
                        <th scope="col">Contactno</th>  
                        <th scope="col">Request</th>
                          
                    </tr>  
                </thead>  
                <tbody>  
                    {this.state.receiver_req.map(item => {  
                        return <tr key={item.reqid}>  
                            <td>{item.reqid}</td>
                            <td>{item.rname}</td>  
                            <td>{item.uniqueid}</td>  
                            <td>{item.email}</td>  
                            <td>{item.address}</td>  
                            <td>{item.contactno}</td>    
                            <td><a className="link link-primary" onClick={(e)=>this.f1(e,item.reqid)}>Approve </a>
                             | <a className="link link-primary" onClick={(event) => this.reject(event,item.reqid)}>Reject</a></td> 
                        </tr>  
                    })}  
                </tbody>  
      </table>
    );
  }

  /*render () {
    let contents = this.state.loading
      ? <p><em>Loading...</em></p>
      : FetchData.renderreceiver_reqTable(this.state.receiver_req);

    return (
      <div>
         
        {contents}
      </div>
    );
  }*/
}
export default FetchData;