import React from "react";
import { Button, Card, CardFooter, CardBody, CardGroup, Col, Container, Form, Input, InputGroup, InputGroupAddon, InputGroupText, Row } from 'reactstrap';


 class  SocialWorkForm extends React.Component{
     constructor(props) {
        super(props);
        this.state = {
          socialwork: {
            
         
                       wid:'',
                       rid:[],
                       donateditem:'',
                      recipient: '',
                
                      location: '',
                
                      datetime: '',
                      description:'',
                      
                
                  
                      
                    }
                  }
                 
                  this.rid = this.rid.bind(this);
                  this.donateditem = this.donateditem.bind(this);
                    this.recipient = this.recipient.bind(this);
                     this.location = this.location.bind(this);
                     this.datetime = this.datetime.bind(this);
                    this.description= this.description.bind(this);
                    this.submit= this.submit.bind(this);
      
                  }
                  
                  rid(event) {
             
                    this.setState({ rid: event.target.value })
              
                  }
                  donateditem(event) {
             
                    this.setState({   donateditem: event.target.value })
              
                  }
                  recipient(event) {
             
                    this.setState({ recipient: event.target.value })
              
                  }
                
                  location(event) {
             
                    this.setState({ location: event.target.value })
              
                  }
          
             
                  datetime(event) {
           
                    this.setState({  datetime: event.target.value })
              
                  }
                  description(event) {
             
                    this.setState({ description: event.target.value })
            
                  }
               
                 
                submit(event) {
  
          
                    fetch('http://localhost:8080/savework', {
                   
                      method: 'post',
             
                      headers: {
               
                        'Accept': 'application/json',
             
                        'Content-Type': 'application/json'
          
                      },
                     
                      
                    "body": JSON.stringify({
            
                         rid:this.state.rid,
                         donateditem:this.state.donateditem,
                        recipient:this.state.recipient,
                       location: this.state.location,
                       datetime: this.state.datetime,
                       description: this.state.description,
              
                        })
            
                    })
                   
                    .then((Response) => Response.json())
                    .then((Response) => {
                               alert("THANK YOU!!!");
                                this.props.history.push("/receiverhome");
                      
                      })
                    
              
                    }
             
               
             
               
                  render() {
              
               
                    return (
             
                        <div className="app flex-row align-items-center">
               
                          <Container>
                  
                            <Row className="justify-content-center">
                  
                              <Col md="9" lg="7" xl="6">
                  
                                <Card className="mx-4">
               
                                  <CardBody className="p-4">
                
                                    <Form>
                  
                                      <div class="row" className="mb-2 pageheading">
               
                                        <div class="col-sm-12 btn btn-primary">
                 
                                          <h2>Add your social deeds</h2>
                
                                          </div>
           
                                      </div>
                                      <lable>Receiver Id</lable><br></br>
                                      
                                      <InputGroup className="mb-3">
             
                                      
                                        <Input type="Object"  onChange={(event) =>this.rid(event)} placeholder="Enter Your Id " />
              
                                      </InputGroup>
                                      <lable>donated Item</lable><br></br>
                                      <InputGroup className="mb-3">
             
                                        <Input type="text"  onChange={(event) =>this.donateditem(event)} placeholder="Enter Donated Item Name" />
               
                                      </InputGroup>
                                      
                                      <lable>Recipient</lable><br></br>
                                      <InputGroup className="mb-3">
             
                                        <Input type="text"  onChange={(event) =>this.recipient(event)} placeholder="To whom You Donated" />
               
                                      </InputGroup>
                                      <lable>location</lable><br></br>
                                        <InputGroup className="mb-3">
             
                                        <Input type="text"  onChange={(event) =>this.location(event)} placeholder="Enter location of Receiver/Organization" />
               
                                      </InputGroup>
                                      <lable>Date/Time</lable><br></br>
                                      <InputGroup className="mb-3">
                                     <Input type="date"  onChange={(event) =>this.datetime(event)} placeholder="Enter Date And Time(yy-mm-dd 00:00:00)" />
                  
                                      </InputGroup>
                                      <lable>Description</lable><br></br>
                                      <InputGroup className="mb-3">
                                     <Input type="email"  onChange={(event) =>this.description(event)} placeholder="Give Description Of Your Work" />
                  
                                      </InputGroup>
                                     
                                      
                                      <Button  onClick={(event) => this.submit(event)}  color="success" >submit</Button>
              
                                    </Form>
               
                                  </CardBody>
               
                                </Card>
               
                              </Col>
           
                            </Row>
          
                          </Container>
               
                        </div>
               
                      );
              
                    }
               
                  }
                  export default SocialWorkForm;