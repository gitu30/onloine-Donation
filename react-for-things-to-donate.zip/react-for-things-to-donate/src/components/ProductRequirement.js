import React, { Component } from 'react';


 class ProductRequirement extends React.Component {
  static displayName = ProductRequirement.name;

  constructor (props) {
    super(props);
    this.state = {
      
productrequirement: [
  {
     prid: "",
      pname: "",
      sid: [  ],
     
      
      rid:[] ,
     
      description: ""
  }],



    loading: true };
   

 


  }
  componentDidMount=()=>{
    const url="http://localhost:8080/allproductreq";

    fetch(url)
    .then(response => response.json())
    .then(data => {
      this.setState({ productrequirement : data, loading: false });
      this.setState({ sid: data, loading: false });
      this.setState({ cid: data, loading: false });
    });
  }
   
  

    
    render=()=>
    {
    return (
              


<table className='table table-border'>
         <thead className="thead-dark">  
         <tr>  
                        <th scope="col">Product ID</th>  
                        <th scope="col">product Name</th>  
                        <th scope="col"><th>Category  :  Subcategory </th></th>

                        <th scope="col">Receiver </th>  
                        <th scope="col">Description</th>  
                        
                       
                          
                    </tr>  
                </thead>  
                <tbody>  
                    {
                    this.state.productrequirement.map((item,i)=>  
                        
                  
                    <tr key={item.prid}>  
                        <td>{item.prid}</td>
                        <td>{item.pname}</td> 

                        <td>{Object.values(item).map((sub)=>{
                       return<table><tr key={sub.sid}>

                         
                         <td>{Object.values(sub).map((subject)=>{
                         return<table><tr key={subject.cid}>

                        
                         <td>{subject.cname}</td>
                         </tr></table>}
                         )}
                      
                         
                         </td>

                      
                       <td> {sub.sname}</td>



                        </tr>
                        </table>
                        }
                           )}
                     </td>

                       

                        
                       
                        <td>   {Object.values(item).map((rub)=>{
                       return<table><tr key={rub.rid}>

                         <td>{rub.rname}</td>
                         <td>{Object.values(rub).map((unos)=>{
                         return<table><tr key={unos.uno}>

                        
                        

                         </tr>
                         </table>
                         
                        }

                         
                         )}
                      
                         
                         </td>

                      
                      
                         <td>{Object.values(rub).map((reqs)=>{
                         return<table><tr key={reqs.reqid}>

                        
                         <td>{reqs.rname}</td>

                         </tr>
                         </table>
                         
                        }

                         
                         )}
                      
                         
                         </td>


                        </tr>
                        </table>
                        }
                           )}     
                           
                           
                                    </td>

                        <td>{item.description}</td>  
                          
                           
                        </tr>  
                     
                        
                       
                  


                    )
                    
                    
                    
                    } 
                </tbody>  

                <tfoot> 
                  <tr> 
                    <td> <li className="list-group-item"><a className="btn btn-outline-success" href="/adddonate">Donate Here</a></li></td>
                  </tr>
                </tfoot>
      </table>


    );
  }

  /*render () {
    let contents = this.state.loading
      ? <p><em>Loading...</em></p>
      : FetchData.renderreceiver_reqTable(this.state.receiver_req);

    return (
      <div>
         
        {contents}
      </div>
    );
  }*/
}
export default ProductRequirement;