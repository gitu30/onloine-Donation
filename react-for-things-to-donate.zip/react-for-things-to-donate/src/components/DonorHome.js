import React from 'react';
class DonorHome extends React.Component{
    constructor(props){
        super(props);

    }
    componentDidMount = () => {
        fetch("")
    }
    render(){
        return(
            <span className="">
            <p className="absolute-center"><h1><b>Wellcome To Donor Home Page</b> </h1></p>
         <h6>"We make a Living by what we get We make a life by what we give."</h6>
            <div className="jumbotron ">
            <form className="col-sm-5">
                <ul className="list-group">
                <li className="list-group-item"><a className="" href="/adddonate">Donate Product </a></li>
                <li className="list-group-item"><a  className="" href="/productrequirement"> View Product Requirement</a></li>
                <li className="list-group-item"><a  className="" href="/socialwork"> View Social Deeds</a></li>
                <li className="list-group-item"><a  className="" href="/donoritems"> Your Donated Items Cart</a></li>
                
                <li className="list-group-item"><a className="btn btn-outline-primary" href="/login">Logout</a></li>
                </ul>
                </form>
            </div></span>
        )
    }
}
export default DonorHome;