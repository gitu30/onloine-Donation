import './App.css';
import {Link,Route} from "react-router-dom";
import Home from './components/Home';
import Login from './components/Login';
import DonorRegister from './components/DonorRegister';
import Register from './components/Register';
import DonorHome from './components/DonorHome';
import ReceiverHome from './components/ReceiverHome';
import AdminHome from './components/AdminHome';

import RequirementRegistration from './components/RequirementRegistration';

import ReceiverRegister from './components/ReceiverRegister';
import ProductRequirement from './components/ProductRequirement';
import ReqMgmt from './components/ReqMgmt';
import DonatedProduct from './components/DonatedProduct';
import SocialWork from './components/SocialWork';
import SocialWorkForm from './components/SocialWorkForm';
import AddDonate from './components/AddDonate';
import DonorItems from './components/DonorItems';
import New from './components/New';


function App() {
  return (
    <div>
      <nav className="navbar navbar-expand-lg navbar-light bg-light">
       <ul>
        <Link className="navbar-brand" to="/">Home</Link>
        <Link className="navbar-brand" to="/login">Login</Link>
        <Link className="navbar-brand" to="/register">Register</Link>
        <Link></Link>
        <Link className="navbar-brand" to="/">Logout</Link>
        
        </ul>

    </nav>
    <div>
      <Route path="/" component={Home} exact />
      <Route path="/login" component={Login}  />
      <Route path="/donorregister" component={DonorRegister} />
      <Route path="/donorhome" component={DonorHome} />
      <Route path="/receiverhome" component={ReceiverHome} />
      <Route path="/adminhome" component={AdminHome} />
 
    
      <Route path="/register" component={Register} />
      <Route path="/receiverregister" component={ReceiverRegister}/>
      <Route path="/requirementregistration" component={RequirementRegistration}/>
      <Route path="/productrequirement" component={ProductRequirement}/>
      <Route path="/reqmgmt" component={ReqMgmt}/>
      <Route path="/donatedproduct" component={DonatedProduct}/>
      <Route path="/socialwork" component={SocialWork}/>
      <Route path="/socialworkform" component={SocialWorkForm}/>
      <Route path="/adddonate" component={AddDonate}/>
      <Route path="/donoritems" component={DonorItems}/>
      <Route path="/new" component={New}/>
      





    </div>
     
    </div>
  );
}

export default App;