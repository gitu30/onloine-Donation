import React from 'react';
class Register extends React.Component{
    constructor(props){
        super(props);

    }
    
    
    render(){
        return(
            <span>
            <h1>Registration Type</h1>
            <div className="jumbotron">
               <form className="col-sm-5">
                <ul className="list-group">
               <li className="list-group-item"><a className="" href="/donorregister"> Donor Registration</a></li>
               <li className="list-group-item"><a className="" href="/receiverregister">NGOs/Social Serving Registration</a></li>
                </ul>
                </form>
                </div></span>
        )
    }
}
export default Register;