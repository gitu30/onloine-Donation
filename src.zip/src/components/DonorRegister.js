import React from "react";
import { Button, Card, CardFooter, CardBody, CardGroup, Col, Container, Form, Input, InputGroup, InputGroupAddon, InputGroupText, Row } from 'reactstrap';


 class DonorRegister extends React.Component{
     constructor(props) {
        super(props);
        this.state = {
          donor: {
            
         
                       uid:'',
                       pwd:'',
                       role:'',
                      fname: '',
                
                      lname: '',
                
                      dob: '',
                      email:'',
                      
                
                  
                      address:'',
                      profession:'',

                
                       contactno: ''
            
                    }
                  }
                  this.uid = this.uid.bind(this);
                  this.pwd = this.pwd.bind(this);
                    this.role = this.role.bind(this);
                     this.fname = this.fname.bind(this);
                     this.lname = this.lname.bind(this);
            
                     this.dob = this.dob.bind(this);
                    this.email = this.email.bind(this);
            
                   
        
                    this.address = this.address.bind(this);
               
                    this.profession = this.profession.bind(this);
             
                    this.contactno = this.contactno.bind(this);
                    this.register = this.register.bind(this);
            
                  }
                  
                  uid(event) {
             
                    this.setState({ uid: event.target.value })
              
                  }
                  pwd(event) {
             
                    this.setState({ pwd: event.target.value })
              
                  }
                  role(event) {
             
                    this.setState({ role: event.target.value })
              
                  }
                
                  fname(event) {
             
                    this.setState({ fname: event.target.value })
              
                  }
          
             
                  lname(event) {
           
                    this.setState({ lname: event.target.value })
              
                  }
                  dob(event) {
             
                    this.setState({ dob: event.target.value })
            
                  }
               
                  email(event) {
             
                    this.setState({ email: event.target.value })
            
                  }
                 
            
                  address(event) {
               
                    this.setState({ address: event.target.value })
            
                  }
              
                  profession(event) {
           
                    this.setState({ profession: event.target.value })
             
                  }
                  contactno(event) {
           
                    this.setState({ contactno: event.target.value })
             
                  }
            
              
                register(event) {
                     alert("Hello");
          
                    fetch('http://localhost:8080/saved', {
                   
                      method: 'post',
             
                      headers: {
               
                        'Accept': 'application/json',
             
                        'Content-Type': 'application/json'
          
                      },
                     
                      
                    "body": JSON.stringify({
            
                         uid:this.state.uid,
                         pwd:this.state.pwd,
                        role:this.state.role,
                       fname: this.state.fname,
                       lname: this.state.lname,
                       dob: this.state.dob,
              
                        email: this.state.email,
                        pwd: this.state.pwd,
              
             
                        address: this.state.address,
            
                       profession: this.state.profession,
                       contactno: this.state.contactno
                     })
            
                    })
                   
                    .then((Response) => Response.json())
                          //.then(response => { console.log(response)
                         // })
                         // .catch(err => {
                           // console.log(err);
                         // });
                      .then((Response) => {
                               alert("you are sucessfully registered");
                                this.props.history.push("/login");
                      
                      })
                    
              
                    }
             
               
             
               
                  render() {
              
               
                    return (
             
                        <div className="app flex-row align-items-center">
               
                          <Container>
                  
                            <Row className="justify-content-center">
                  
                              <Col md="9" lg="7" xl="6">
                  
                                <Card className="mx-4">
               
                                  <CardBody className="p-4">
                
                                    <Form>
                  
                                      <div class="row" className="mb-2 pageheading">
               
                                        <div class="col-sm-12 btn btn-primary">
                 
                                          <h2>Sign Up</h2>
                
                                          </div>
           
                                      </div>
                                      <lable>User Id</lable><br></br>
                                      
                                      <InputGroup className="mb-3">
             
                                        
                                        <Input type="text"  onChange={(event) =>this.uid(event)} placeholder="create userid " />
              
                                      </InputGroup>
                                      <lable>Password</lable><br></br>
                                      <InputGroup className="mb-3">
             
                                        <Input type="password"  onChange={(event) =>this.pwd(event)} placeholder="Enter password" />
               
                                      </InputGroup>
                                      
                                      <InputGroup className="mb-3">
                                      <select className="btn btn-success dropdown-toggle "  name="Role" id="roles" hidden>
                                           <option value="donor">Donor</option>
                                           <option value="reciever" disabled>Reciever</option>
                                       </select>
                                       </InputGroup>
                                      <lable>First Name</lable><br></br>
                                      <InputGroup className="mb-3">
             
                                        <Input type="text"  onChange={(event) =>this.fname(event)} placeholder="Enter First Name" />
               
                                      </InputGroup>
                                      <lable>Last Name</lable><br></br>
                                        <InputGroup className="mb-3">
             
                                        <Input type="text"  onChange={(event) =>this.lname(event)} placeholder="Enter last name" />
               
                                      </InputGroup>
                                      <lable>Birthdate</lable><br></br>
                                      <InputGroup className="mb-3">
                                     <Input type="date"  onChange={(event) =>this.dob(event)} placeholder="Enter date of birth " />
                  
                                      </InputGroup>
                                      <lable>Email</lable><br></br>
                                      <InputGroup className="mb-3">
                                     <Input type="email"  onChange={(event) =>this.email(event)} placeholder="Enter email" />
                  
                                      </InputGroup>
                                     
                                      <lable>Address</lable><br></br>
                                      <InputGroup className="mb-4">
              
                                        <Input type="text"  onChange={(event) =>this.address(event)} placeholder="Enter address" />
           
                                      </InputGroup>
                                      <lable>Profession</lable><br></br>
                                      <InputGroup className="mb-4">
             
                                        <Input type="text"  onChange={(event) =>this.profession(event)} placeholder="Enter profession" />
                                     </InputGroup>
                                     <lable>Contact Number</lable><br></br>
                                     <InputGroup className="mb-4">
             
                                        <Input type="number"  onChange={(event) =>this.contactno(event)} placeholder="Enter contactno" />
                                     </InputGroup>
              
                                      <Button  onClick={(event) => this.register(event)}  color="success" >Create Account</Button>
              
                                    </Form>
               
                                  </CardBody>
               
                                </Card>
               
                              </Col>
           
                            </Row>
          
                          </Container>
               
                        </div>
               
                      );
              
                    }
               
                  }
                  export default DonorRegister;
                      
                                
              
                                 