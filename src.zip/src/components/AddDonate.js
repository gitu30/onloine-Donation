import React from "react";

import { Button, Card, CardFooter, CardBody, CardGroup, Col, Container, Form, Input, InputGroup, InputGroupAddon, InputGroupText, Row } from 'reactstrap';


 class AddDonate extends React.Component{

     constructor(props)
     {
         super(props);
         this.state={
             categories: [],
             subcategories: [],
             cid: 0,
             pname:'',
             did:'',
             image:'',
             quantity:'',
             pstatus:'',
         }
         this.cid=this.cid.bind(this);
         this.pname=this.pname.bind(this);
         this.did=this.did.bind(this);
         this.image=this.image.bind(this);
         this.quantity=this.quantity.bind(this);
         this.pstatus=this.pstatus.bind(this);
         this.register=this.register.bind(this);
     }
  
     componentDidMount=()=>{
         fetch("http://localhost:8080/allcat")
         .then(resp => resp.json())
         .then(data => this.setState({categories: data}))
     }

     cid=(event)=>{
         this.setState({cid: event.target.value})
         alert(event.target.value)
          fetch("http://localhost:8080/getByid?cid="+event.target.value)
        .then(resp => resp.json())
         .then(data => this.setState({subcategories: data}))
         //this.getSubCat();
     }

     getSubCat=()=>{
         alert(this.state.cid)
          fetch("http://localhost:8080/getByid?cid="+this.state.cid)
        .then(resp => resp.json())
         .then(data => this.setState({subcategories: data}))
     }
     pname(event) {
             
        this.setState({ pname: event.target.value })
  
      }
      did(event){
          this.setState({did:event.target.value})
      }
      image(event) {
             
        this.setState({ image: event.target.value })
  
      }
      quantity(event) {
             
        this.setState({ quantity: event.target.value })
  
      }
      pstatus(event) {
             
        this.setState({ pstatus: event.target.value })
  
      }
      pname(event) {
             
        this.setState({ pname: event.target.value })
  
      }
      register(event) {
  
          
        fetch('http://localhost:8080/saveproducts', {
       
          method: 'post',
 
          headers: {
   
            'Accept': 'application/json',
 
            'Content-Type': 'application/json'

          },
         
          
        "body": JSON.stringify({

             pname:this.state.pname,
             did:this.state.did,
             image:this.state.image,
            quantity:this.state.quantity,
            pstatus:this.state.pstatus,
           
         })

        })
       
        .then((Response) => Response.json())
              //.then(response => { console.log(response)
             // })
             // .catch(err => {
               // console.log(err);
             // });
          .then((Response) => {
                   alert("Thank You For Contribution!!");
                    this.props.history.push("/donorhome");
          
          })
        
  
        }
 
    render(){
        return(
           
            <div className="container" className="row" className="col-sm-4">
               <form className="container-fluid jumbotron" >
                <h1>Donate Here/Add Product Information </h1>
                                     <lable>Product Name</lable><br></br>
                                   <InputGroup className="mb-3">     
                                      <Input type="text"  onChange={(event) =>this.pname(event)} placeholder="add product name " />
                                      </InputGroup>
                                      <lable>Donor Id</lable><br></br>
                                   <InputGroup className="mb-3">     
                                      <Input type="text"  onChange={(event) =>this.did(event)} placeholder="add your  id " />
                                      </InputGroup>
                                      <lable>Add Image</lable><br></br>
                                   <InputGroup className="mb-3">     
                                      <Input type="text"  onChange={(event) =>this.image(event)} placeholder=" add image here" />
                                      </InputGroup>
                                      <lable>Add Quantity</lable><br></br>
                                   <InputGroup className="mb-3">     
                                      <Input type="text"  onChange={(event) =>this.quantity(event)} placeholder="add quantity " />
                                      </InputGroup>
                                     
                
                <label>Select Category</label>
                <InputGroup className="mb-3">
                <select onChange={this.cid}>
                  {
                      this.state.categories.map(cat => {
                          return(<option value={cat.cid}>{cat.cname}</option>)
                      })
                  }
                  
                </select>
                </InputGroup>
                   {/*<p>{this.state.cid}</p>*/}
                 <br/>
                <label>Select subcategory</label>
                <InputGroup className="mb-3"> 
                <select className="" >
                {
                      this.state.subcategories.map(subcat => {
                          return(<option value={subcat.sid}>{subcat.sname}</option>)
                      })
                  }
                </select><br></br>
                </InputGroup>
                <lable >Status</lable><br></br>
                <InputGroup className="mb-4">
                                        <select className="btn btn-primary  " value={this.pstatus} onChange={(event) =>this.pstatus(event)}  >
                                          <option >Available</option>
                                          <option value={this.pstatus} hidden> Available</option>
                                         
                                        </select>
                                      
                                     </InputGroup>
                                     <br>
                                    </br>
                                    <br>
                                    </br>
                 <InputGroup>
                <Button  onClick={(event) => this.register(event)}  color="success" >Donate</Button>
                </InputGroup>
                   
                </form>
                </div>

           
        );
                 
            
        
    }
}
export default AddDonate;