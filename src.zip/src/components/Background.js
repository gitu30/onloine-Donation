import React from "react";
import donate from "./donate.jpg"

function Background()
{
    console.log(donate);
    return(
        <div>
            <img src={donate} alt="donate image" height={500} width={500} ></img>
        </div>
    );
}

export default Background;