
import React from "react";
import { Table } from "reactstrap";


 class DonorItems extends React.Component{

     constructor(props)
     {
        super(props);
         this.state={
             donor: [],
             product: [],
             did: 0
         }
         this.did=this.did.bind(this);
     }
  
     componentDidMount=()=>{
         fetch("http://localhost:8080/getAlldonor")
         .then(resp => resp.json())
         //alert("get all donors")
         .then(data => this.setState({donor: data}))
     }

     did=(event)=>{
         this.setState({did: event.target.value})
         alert(event.target.value)
          fetch("http://localhost:8080/getBydid?did="+event.target.value)
          
        .then(resp => resp.json())
       
         .then(data => this.setState({product: data}))
         //this.getSubCat();
     }

    
    render(){
        return(
          <div className="container" className="row" className="col-sm-4">
          <form className="container-fluid jumbotron" >
           <h2> Donated Cart</h2>
           <label>Select Your Mail</label><br></br>
           <select onChange={this.did}>
             {
                 this.state.donor.map(cat => {
                     return(<option value={cat.did}>{cat.email}</option>)
                 })
             }
           </select>
               <p>{this.state.did}</p>
            <br/>
          <h3> Your Donated Cart :</h3>
          <table  className='table table-border'>
          <thead className='thead thead-dark'><th>Product Id</th>   <th>Product Name</th><th>Quantity</th></thead>
           {
                 this.state.product.map(subcat => {
                     return (      
                   
                     
                     <tbody><tr key={subcat.did}> <td>{subcat.pid}</td><td>{subcat.pname}</td><td>{subcat.quantity}</td></tr> </tbody>)
                 })
                
             }
           </table>
           </form>
           </div>

        
     );
              
         
     
 }
}

  /*render () {
    let contents = this.state.loading
      ? <p><em>Loading...</em></p>
      : FetchData.renderreceiver_reqTable(this.state.receiver_req);

    return (
      <div>
         
        {contents}
      </div>
    );
  }*/

export default  DonorItems;