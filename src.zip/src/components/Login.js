import React from "react";

 class Login extends React.Component{
     constructor(props)
       {
         super(props);
         this.state = {
             msg:"",
             loginerror:""

            }

        }
        checkLogin = () => {
         let uid = this.refs.uid.value;
         let pwd = this.refs.pwd.value;

         const url = "http://localhost:8080/checkLogin?uid="+uid+"&pwd="+pwd;
         fetch(url)
         .then(Response => Response.text())
         .then(data => {
           if(data == "donor")
              this.props.history.push("/donorhome/"+uid);
            else if(data == "receiver")
              this.props.history.push("/receiverhome/"+uid);
            else if(data == "admin")
              this.props.history.push("/adminhome/"+uid);
            else if(data == "")
              this.setState({loginerror: "Wrong ID/Pwd"});
         });

       }
       render(){
         return(
          
              <div className="container" className="row" className="col-sm-4"  >
              
                 <h1>Login page</h1>
                 <form className="container-fluid jumbotron">
                      <p className="fst-normal">Enter Username</p>
                       <input className="from form-control" type="text" ref="uid" placeholder=" Enter userid " />
                          <p className="fst-normal">Enter Password</p>
                          <input type="password" ref="pwd" className="from form-control" placeholder="Enter password" /><p></p>
                      <input type="button" onClick={this.checkLogin}  value="LOGIN" className="btn btn-success"/>
                   </form>
                    <p>{this.state.loginerror}</p>
                    </div>
             
        
            );
        }         
            
        
       
    }
export default Login;