package com.example.demo.entities;

	

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
	import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonFormat;


	@Entity
	@Table(name ="socialwork")
	public class SocialWork 
	{
		@Id
		@GeneratedValue(strategy = GenerationType.IDENTITY)
		int wid;
		@OneToOne
		@JoinColumn(name="rid")
		Receiver rid;
		@Column
		String donateditem;
		@Column
		String recipient;
		@Column
		String location;
		@JsonFormat(pattern="yyyy-MM-dd")
		@Column
		Date datetime;
		@Column
		String description;
			
		public SocialWork() 
		{
			super();
			// TODO Auto-generated constructor stub
		}

		public SocialWork(Receiver rid, String donateditem, String recipient, String location, Date datetime,
				String description) 
		{
			super();
			
			this.rid = rid;
			this.donateditem = donateditem;
			this.recipient = recipient;
			this.location = location;
			this.datetime = datetime;
			this.description = description;
		}

		

		public SocialWork(Receiver r, String donateditem, Date datetime, String location, String recipient,
				String description) {

			this.rid = r;
			
			this.donateditem = donateditem;
			this.datetime = datetime;
			this.location = location;
		
			this.recipient = recipient;
			
			this.description = description;
			
			
		}

		public int getWid() {
			return wid;
		}

		public void setWid(int wid) {
			this.wid = wid;
		}

		public Receiver getRid() {
			return rid;
		}

		public void setRid(Receiver rid) {
			this.rid = rid;
		}

		public String getDonateditem() {
			return donateditem;
		}

		public void setDonateditem(String donateditem) {
			this.donateditem = donateditem;
		}

		public String getRecipient() {
			return recipient;
		}

		public void setRecipient(String recipient) {
			this.recipient = recipient;
		}

		public String getLocation() {
			return location;
		}

		public void setLocation(String location) {
			this.location = location;
		}

		public Date getDatetime() {
			return datetime;
		}

		public void setDatetime(Date datetime) {
			this.datetime = datetime;
		}

		public String getDescription() {
			return description;
		}

		public void setDescription(String description) {
			this.description = description;
		}

		
		
			

	}