package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entities.Category;
import com.example.demo.entities.Donor;
import com.example.demo.entities.Login;
import com.example.demo.entities.ProductRequirement;
import com.example.demo.entities.ProductRequirementData;
import com.example.demo.entities.Receiver;
import com.example.demo.entities.Receiver_Req;
import com.example.demo.entities.SocialWork;
import com.example.demo.entities.SubCategory;
import com.example.demo.services.CategoryService;
import com.example.demo.services.LoginService;
import com.example.demo.services.ProductRequirementService;
import com.example.demo.services.ReceiverApprovedService;
import com.example.demo.services.ReceiverRegisterService;
import com.example.demo.services.SubCategoryService;


@CrossOrigin(origins = "http://localhost:3000")
@RestController
public class ProductRequirementController {
	@Autowired
	ProductRequirementService sservice;
	
	@Autowired
	SubCategoryService scservice;
	
	@Autowired
	CategoryService ccservice;
	
	@Autowired
	ReceiverApprovedService cservice;
	@Autowired
	ReceiverRegisterService rservice;
	
	@Autowired
	LoginService lservice;
	@GetMapping("/allproductreq")
	public List<ProductRequirement> getAll()
	{
		return sservice.getAll();
	}
	
	@PostMapping("/saveproductreq")
	public ProductRequirement save(@RequestBody ProductRequirementData st)
	{
		
		int uno = 0;
		Login l=lservice.getOne(uno); 
		int reqid=0;
		Receiver_Req rr=rservice.getOne(reqid);
		Receiver r=new Receiver(st.getRid(),rr,l);
		
		int cid=0;
		Category c=ccservice.getOne(cid);
		SubCategory sc=new SubCategory(st.getSid(),c);
		ProductRequirement s=new  ProductRequirement (st.getPname(),sc,r,st.getDescription());
		
		return sservice.save(s);
		
	}
}