package com.example.demo.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
@Entity
@Table(name="receiver")
public class Receiver {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column
	int rid;
	

	@OneToOne
	@JoinColumn(name="reqid")
	Receiver_Req reqid;
	


	@OneToOne
	@JoinColumn(name="uno")
	Login uno;

	public Receiver() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Receiver(int rid, Receiver_Req reqid,Login uno) {
		super();
		this.rid=rid;
		this.reqid = reqid;
		this.uno = uno;
	}
	

	public int getRid() {
		return rid;
	}

	public void setRid(int rid) {
		this.rid = rid;
	}

	public Receiver_Req getReqid() {
		return reqid;
	}

	public void setReqid(Receiver_Req reqid) {
		this.reqid = reqid;
	}
	public Login getUno() {
		return uno;
	}

	public void setUno(Login uno) {
		this.uno = uno;
	}
	
	public Receiver(int rid) 
	{
		super();
		this.rid = rid;
		
	}

	

	public Receiver( Receiver_Req reqid,Login uno) {
		this.uno=uno;
		this.reqid=reqid;
	}
	
	public Receiver( int rid,Login uno) {
		this.uno=uno;
		this.rid=rid;
	}

	public Receiver(Login uno2, Receiver_Req c) {
		this.uno=uno2;
		this.reqid=c;
	}

	
	
	}