package com.example.demo.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.example.demo.entities.Category;
import com.example.demo.entities.SubCategory;

@Repository
public interface SubCategoryRepository extends JpaRepository<SubCategory,Integer> 
{

	
	@Query("select s from SubCategory s where cid = ?1 ")
	public List<SubCategory> getByid(Category c);
	
	//public List<SubCategory> getAll(cid);

	

	/*@Query("select s from SubCategory s where s.cid= :cid ")
	public SubCategory  allsubcat(Integer cid);*/
	
	
	

	//natural join Category c  where s.cid = c.cid

	

	

	

}
