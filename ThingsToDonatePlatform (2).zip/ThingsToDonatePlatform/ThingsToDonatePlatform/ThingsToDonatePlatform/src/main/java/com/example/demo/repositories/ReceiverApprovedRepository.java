package com.example.demo.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.example.demo.entities.Category;
import com.example.demo.entities.Login;
import com.example.demo.entities.Receiver;
import com.example.demo.entities.Receiver_Req;
import com.example.demo.entities.SubCategory;

public interface ReceiverApprovedRepository extends JpaRepository<Receiver, Integer> {

	Receiver save(int rid);

	//Receiver getOne(int rid, Receiver_Req rr, Login l);

	//@Query("select r from Receiver r where reqid = ?1 ")
	//public List<Receiver> getByid(Receiver_Req c);
	
	
	
	

}
