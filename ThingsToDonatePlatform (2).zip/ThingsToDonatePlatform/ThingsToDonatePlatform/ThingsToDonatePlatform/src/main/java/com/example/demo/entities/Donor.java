package com.example.demo.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
@Entity
@Table(name="donor")
public class Donor {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	int did;
	@Column
	String fname;
	@Column
	String lname;
	@Column
	String dob;
	@Column
	String email;
	
	@Column 
	String address;
	@Column
	String profession;
	@Column
	String contactno;
	@OneToOne
	@JoinColumn(name="uno")
	Login uno;
	
	
	
	
	public Donor() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	
	
	public Donor(String fname, String lname, String dob, String email, String address, String profession,
			String contactno, Login uno) {
		super();
		this.fname = fname;
		this.lname = lname;
		this.dob = dob;
		this.email = email;
		this.address = address;
		this.profession = profession;
		this.contactno = contactno;
		this.uno = uno;
	}




	public int getDid() {
		return did;
	}
	public void setDid(int did) {
		this.did = did;
	}
	public String getFname() {
		return fname;
	}
	public void setFname(String fname) {
		this.fname = fname;
	}
	public String getLname() {
		return lname;
	}
	public void setLname(String lname) {
		this.lname = lname;
	}
	public String getDob() {
		return dob;
	}
	public void setDob(String dob) {
		this.dob = dob;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getProfession() {
		return profession;
	}
	public void setProfession(String profession) {
		this.profession = profession;
	}
	public String getContactno() {
		return contactno;
	}
	public void setContactno(String contactno) {
		this.contactno = contactno;
	}
	public Donor(int did) 
	{
		super();
		this.did = did;
		
	}




	public Donor(int did2, Login l) {
		super();
		this.did = did2;
		this.uno=l;
	}
	
}
