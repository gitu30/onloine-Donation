package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entities.Donor;
import com.example.demo.entities.DonorRegister;
import com.example.demo.entities.Login;
import com.example.demo.services.DonorService;
import com.example.demo.services.LoginService;



@CrossOrigin(origins = "http://localhost:3000")
@RestController


public class DonorRegisterController {
	@Autowired
	DonorService  lservice;
	@Autowired
	LoginService sservice;
	/*@GetMapping("/saves")
	public String registerdonor(@RequestParam("did")String did,@RequestParam("fname")String fname,@RequestParam("lname")String lname,@RequestParam("dob")String dob,@RequestParam("email")String email,@RequestParam("pwd")String pwd,@RequestParam("address")String address,@RequestParam("profession")String profession,@RequestParam("contactno")String contactno)
	{
		return lservice.registerdonor(did,fname,lname,dob,email,pwd,address,profession,contactno);
	}*/

	/*
	public List<Donor> getAll(){
		
		return lservice.getAll();
	}*/


@PostMapping("/saved")
public Donor save(@RequestBody DonorRegister dt)
{
	Login l =new Login(dt.getUid(), dt.getPwd() ,"donor");
	Login uno = sservice.save(l);
	
	
	Donor d = new Donor(dt.getFname(),dt.getLname(),dt.getDob(),dt.getEmail(),dt.getAddress(),dt.getProfession(),dt.getContactno(),uno);
	return lservice.save(d);
}

/*@GetMapping("/getOne")
public Donor getOne(@RequestParam("did")String id)
{
	return lservice .getOne(id);
}*/
@GetMapping("/getAlldonor")
public List<Donor> getAllDonor()
{
	return lservice .getAllDonor();
}
}

