package com.example.demo.entities;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
@Entity
@Table(name="receiver_req")
public class Receiver_Req {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	int reqid;
     @Column
	String rname;
     @Column
	String uniqueid;
     @Column
	String email;
     @Column
 	String pwd;
     @Column
     String uid;
     @Column
	String address;
     @Column
	int requeststatus;
     @Column
	String contactno;
     

	public Receiver_Req() {
		super();
		
	}


	public Receiver_Req(int reqid, String rname, String uniqueid, String email, String pwd, String uid, String address,
			int requeststatus, String contactno) {
		super();
		this.reqid = reqid;
		this.rname = rname;
		this.uniqueid = uniqueid;
		this.email = email;
		this.pwd = pwd;
		this.uid = uid;
		this.address = address;
		this.requeststatus = requeststatus;
		this.contactno = contactno;
	}


	

	public Receiver_Req(int reqid, String email, String pwd) {
		this.reqid=reqid;
		this.email=email;
		this.pwd=pwd;
	}


	public int getReqid() {
		return reqid;
	}


	public void setReqid(int reqid) {
		this.reqid = reqid;
	}


	public String getRname() {
		return rname;
	}


	public void setRname(String rname) {
		this.rname = rname;
	}


	public String getUniqueid() {
		return uniqueid;
	}


	public void setUniqueid(String uniqueid) {
		this.uniqueid = uniqueid;
	}


	public String getEmail() {
		return email;
	}


	public void setEmail(String email) {
		this.email = email;
	}


	public String getPwd() {
		return pwd;
	}


	public void setPwd(String pwd) {
		this.pwd = pwd;
	}


	public String getUid() {
		return uid;
	}


	public void setUid(String uid) {
		this.uid = uid;
	}


	public String getAddress() {
		return address;
	}


	public void setAddress(String address) {
		this.address = address;
	}


	public int getRequeststatus() {
		return requeststatus;
	}


	public void setRequeststatus(int requeststatus) {
		this.requeststatus = requeststatus;
	}


	public String getContactno() {
		return contactno;
	}


	public void setContactno(String contactno) {
		this.contactno = contactno;
	}
	

	

	

}

