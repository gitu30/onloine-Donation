package com.example.demo.services;

import java.util.List;
import java.util.NoSuchElementException;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entities.*;
import com.example.demo.repositories.CategoryRepository;

@Service
public class CategoryService 
{
	@Autowired
	CategoryRepository crepo;
	/*public String selectCategory(int cid, String cname)
	{
		return crepo.selectCategory(cid,cname);
	}
	
	public Category getOne(int cid, String cname)
	{
		Optional<Category> ol = crepo.findById(cid);
		Category c = null;
		try
		{
			c = ol.get();
		}
		catch(NoSuchElementException e)
		{
			c =null;
		}
		return c;
	}
	*/
	public  List<Category> getAll()
	{
		return crepo.findAll();
	}
	
	public Category getOne(int id)
	{
		Optional<Category> oc = crepo.findById(id);
		Category c = null;
		try
		{
			c = oc.get();
		}
		catch(NoSuchElementException e)
		{
			c=null;
		}
		return c;
		
		
		
	}
	

}
