package com.example.demo.entities;

import java.util.Date;

public class SocialWorkData {
int rid;
     String donateditem;
   String recipient;
   String location;
   Date datetime;
   String description;
   
public int getRid() {
	return rid;
}

public void setRid(int rid) {
	this.rid = rid;
}

public String getDonateditem() {
	return donateditem;
}

public void setDonateditem(String donateditem) {
	this.donateditem = donateditem;
}

public String getRecipient() {
	return recipient;
}

public void setRecipient(String recipient) {
	this.recipient = recipient;
}

public String getLocation() {
	return location;
}

public void setLocation(String location) {
	this.location = location;
}

public Date getDatetime() {
	return datetime;
}

public void setDatetime(Date datetime) {
	this.datetime = datetime;
}

public String getDescription() {
	return description;
}

public void setDescription(String description) {
	this.description = description;
}

public SocialWorkData() {
	super();
	// TODO Auto-generated constructor stub
}
}
