package com.example.demo.controller;



import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entities.Login;
import com.example.demo.entities.ProductRequirement;
import com.example.demo.entities.Receiver;
import com.example.demo.entities.Receiver_Req;
import com.example.demo.entities.SocialWork;
import com.example.demo.entities.SocialWorkData;
import com.example.demo.services.LoginService;
import com.example.demo.services.ProductRequirementService;
import com.example.demo.services.ReceiverApprovedService;
import com.example.demo.services.ReceiverRegisterService;
import com.example.demo.services.SocialWorkService;
import com.example.demo.services.SubCategoryService;


@CrossOrigin(origins = "http://localhost:3000")
@RestController
public class SocialWorkController

{
	@Autowired
	SocialWorkService swservice;
	
	@Autowired
	ReceiverApprovedService cservice;
	@Autowired
	ReceiverRegisterService rservice;
	
	@Autowired
	LoginService lservice;
	@GetMapping("/allwork")
	public List<SocialWork> getAll()
	{
		return swservice.getAll();
	}
	
	@PostMapping("/savework")
	public SocialWork save(@RequestBody SocialWorkData st)
	{   
		
		int uno = 0;
		Login l=lservice.getOne(uno); 
		int reqid=0;
		Receiver_Req rr=rservice.getOne(reqid);
		Receiver r=new Receiver(st.getRid(),rr,l);
		SocialWork s=new SocialWork (r,st.getDonateditem(),st.getDatetime(),st.getLocation(),st.getRecipient(),st.getDescription());
		
		return swservice.save(s);
		

		
		
		
		
	}
}