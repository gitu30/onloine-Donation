package com.example.demo.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.example.demo.entities.*;;

@Entity
@Table(name = "subcategory")
public class SubCategory 
{
	@Id
	int sid;
	@ManyToOne
	@JoinColumn(name="cid")
	Category cid;
	@Column
	String sname;
	
	public SubCategory()
	{
		super();
		// TODO Auto-generated constructor stub
	}

	public SubCategory(int sid, Category cid, String sname) 
	{
		super();
		this.sid = sid;
		this.cid = cid;
		this.sname = sname;
	}

	public int getSid() {
		return sid;
	}

	public void setSid(int sid) {
		this.sid = sid;
	}

	public Category getCid() {
		return cid;
	}

	public void setCid(Category cid) {
		this.cid = cid;
	}

	public String getSname() {
		return sname;
	}

	public void setSname(String sname) {
		this.sname = sname;
	}
	
	
	public SubCategory(int sid) 
	{
		super();
		this.sid = sid;
		
	}

	public SubCategory(int sid2, Category c) {
		this.sid=sid2;
		this.cid=c;
	}
	
	
	
	

}
