package com.example.demo.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.example.demo.entities.Donor;
import com.example.demo.entities.Product;
import com.example.demo.entities.ProductRequirement;
import com.example.demo.entities.Receiver;
import com.example.demo.entities.SubCategory;




@Repository
public interface ProductRepository extends CrudRepository<Product, Integer> {

	

	
	/*@Query("select p from product p where did = ?1 ")
	public List<SubCategory> getByid();*/
	
	//Product save(Product p);
	@Query("select s from Product s where did = ?1 ")
	//List<Product> findAll(Receiver r);


	List<Product> getByid(Donor r);

	


}
