package com.example.demo.services;


import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entities.Donor;
import com.example.demo.entities.Product;
import com.example.demo.entities.ProductRequirement;
import com.example.demo.entities.Receiver;
import com.example.demo.repositories.ProductRepository;

@Service
public class ProductServices {
	@Autowired
	ProductRepository prepo;
	/*
public List<ProductRequirement> getAllProduct() {
		
		List<ProductRequirement> ProductRequirement= new ArrayList<ProductRequirement>();  
		
		// TODO Auto-generated method stub
	
		
				
				return prepo.
		
	}
}
*/

	public List<Product> getAllProduct() {
		
		List<Product> products= new ArrayList<Product>();  
		
		// TODO Auto-generated method stub
		
		
				prepo.findAll().forEach(products1->products.add(products1));
				return products;
		
	}

public Product getProductById(int pid) {
	// TODO Auto-generated method stub
	return prepo.findById(pid).get();
}
public Product updateProduct(Product product)

{
	return prepo.save(product);
	
}



public void deleteProduct(int pid)
{
	prepo.deleteById(pid);
}

	/*public Product addProduct(Product product) {
		
	return 	prepo.save(product);*/
		
public Product save(Product p) {
	// TODO Auto-generated method stub
	return prepo.save(p);
}
		
	
	

	
	
@SuppressWarnings("unchecked")
public List<Product> getProduct(int pid) {
		
		
		// TODO Auto-generated method stub
		return (List<Product>) prepo.findById(pid).get();
		
	}

public Receiver saver(Receiver l) {
	// TODO Auto-generated method stub
	return null;
}



public List<Product> getAllProduct(Donor r) {
	// TODO Auto-generated method stub
	return prepo.getByid(r);
}

public List<Product> getByid(Donor r) {
	// TODO Auto-generated method stub
	return null;
}


	
}
	

	
	/*

   	@Override
	public void deleteCourse(long parseLong) {
 //list=this.list.stream().filter(e->e.getId()!=parseLong).collect(Collectors.toList());
 Course entity =	courseDao.getOne(parseLong);
 courseDao.delete(entity);
	}
	*/
  
