package com.example.demo.services;

import java.util.List;
import java.util.NoSuchElementException;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entities.SubCategory;
import com.example.demo.entities.*;
import com.example.demo.repositories.CategoryRepository;
import com.example.demo.repositories.SubCategoryRepository;

@Service
public class SubCategoryService 
{
	@Autowired
	SubCategoryRepository screpo;
	
	/*public SubCategory getOne(int cid)
	{
		Optional<SubCategory> stu = screpo.findById(cid);
		SubCategory s = null;
		try
		{
			s = stu.get();
		}
		catch(NoSuchElementException e)
		{
			s=null;
		}
		return s;
	}*/
	
	public List<SubCategory> getByid(Category c) {
		// TODO Auto-generated method stub
		return screpo.getByid(c) ;
	}

	
	
	/*public SubCategory allsubcat(Integer cid)
	{
		return screpo.allsubcat(cid) ;
	}*/


}
