package com.example.demo.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.demo.entities.ProductRequirement;

@Repository
public interface ProductRequirementRepository extends JpaRepository<ProductRequirement, Integer>  {

	//@SuppressWarnings("unchecked")
	ProductRequirement save(ProductRequirement pr);

	List<ProductRequirement> findAll();

}
