package com.example.demo.repositories;
import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.example.demo.entities.Receiver;
import com.example.demo.entities.Receiver_Req;


@Repository
public interface ReceiverRegisterRepository extends JpaRepository<Receiver_Req, Integer> {

	Receiver_Req save(Receiver_Req rt);

	/*@Query("select r from Receiver_Req r  where requeststatus =0")
	public  List<Receiver_Req>  getByAll();*/
	
	@Query("select r from Receiver_Req r where requeststatus = '0'")
	public  List<Receiver_Req>  getFromrequeststatus();
	
	@Modifying
	@Transactional
	@Query("update Receiver_Req r set requeststatus = 1 where r.reqid = ?1 ")
	public int updateStatus(int reqid);
}