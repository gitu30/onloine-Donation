package com.example.demo.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.repositories.ReceiverApprovedRepository;
import com.example.demo.repositories.ReceiverRegisterRepository;
import com.example.demo.entities.*;
@Service
public class ReceiverApprovedService {

	@Autowired
	ReceiverApprovedRepository repo;
	
	public Receiver saved(Receiver r)
	{
		 return repo.save(r);
	}

	
	

	

	public Receiver getOne(int rid) {
		// TODO Auto-generated method stub
		return repo.save(rid);
	}














	
	
}
