package com.example.demo.services;




	import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
	import org.springframework.stereotype.Service;

import com.example.demo.entities.ProductRequirement;
import com.example.demo.entities.SocialWork;
import com.example.demo.repositories.ProductRequirementRepository;
import com.example.demo.repositories.SocialWorkRepository;


	@Service
	public class SocialWorkService 
	{
		@Autowired
		SocialWorkRepository prepo;
		
		
		public  List<SocialWork> getAll()
		{
			return prepo.findAll();
		}
		
		
		public SocialWork save(SocialWork st) {
			// TODO Auto-generated method stub
			return prepo.save(st);
		}

		
		
		
		
	}