package com.example.demo.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entities.ProductRequirement;
import com.example.demo.entities.Receiver;
import com.example.demo.repositories.ProductRequirementRepository;


@Service
public class ProductRequirementService {
	@Autowired
	ProductRequirementRepository prepo;
	
	
	public  List<ProductRequirement> getAll()
	{
		return prepo.findAll();
	}
	
	
	public ProductRequirement save(ProductRequirement st) {
		// TODO Auto-generated method stub
		return prepo.save(st);
	}

}
