package com.example.demo.entities;

public class ProductRequirementData {
 int prid;
 String pname;
 int sid;
 int rid;
 String description;
public ProductRequirementData() {
	super();
	// TODO Auto-generated constructor stub
}
public int getPrid() {
	return prid;
}
public void setPrid(int prid) {
	this.prid = prid;
}
public String getPname() {
	return pname;
}
public void setPname(String pname) {
	this.pname = pname;
}
public int getSid() {
	return sid;
}
public void setSid(int sid) {
	this.sid = sid;
}
public int getRid() {
	return rid;
}
public void setRid(int rid) {
	this.rid = rid;
}
public String getDescription() {
	return description;
}
public void setDescription(String description) {
	this.description = description;
}
 
}
