package com.example.demo.entities;

public class ReceiverRegister {
	int rid;
	public int reqid;
	int uno;
	
	
	public ReceiverRegister() {
		super();
	}
	public int getRid() {
		return rid;
	}
	public void setRid(int rid) {
		this.rid = rid;
	}
	public int getReqid() {
		return reqid;
	}
	public void setReqid(int reqid) {
		this.reqid = reqid;
	}
	public int getUno() {
		return uno;
	}
	public void setUno(int uno) {
		this.uno = uno;
	}
	public String getUid() {
		// TODO Auto-generated method stub
		return null;
	}
	public String getPwd() {
		// TODO Auto-generated method stub
		return null;
	}
	

}
