package com.example.demo.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="product")
public class Product {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	 int pid;
	@Column
	 String pname;

	@ManyToOne
	@JoinColumn(name="did")
	 Donor did;
	@Column
	 String image;
	@Column
	 double quantity;
	@Column
     String pstatus;
	public Product(int pid, String pname, Donor did, String image, double quantity, String pstatus) {
		super();
		this.pid = pid;
		this.pname = pname;
		this.did = did;
		this.image = image;
		this.quantity = quantity;
		this.pstatus = pstatus;
	}
	
	public Product() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Product(Donor d, String pname2, String image2, double quantity2, String pstatus2) {
		this.did=d;
		this.pname = pname2;
		
		this.image = image2;
		this.quantity = quantity2;
		this.pstatus = pstatus2;
	}

	public int getPid() {
		return pid;
	}
	public void setPid(int pid) {
		this.pid = pid;
	}
	public String getPname() {
		return pname;
	}
	public void setPname(String pname) {
		this.pname = pname;
	}
	public Donor getDid() {
		return did;
	}
	public void setDid(Donor did) {
		this.did = did;
	}
	public String getImage() {
		return image;
	}
	public void setImage(String image) {
		this.image = image;
	}
	
	public double getQuantity() {
		return quantity;
	}

	public void setQuantity(double quantity) {
		this.quantity = quantity;
	}

	public String getPstatus() {
		return pstatus;
	}
	public void setPstatus(String pstatus) {
		this.pstatus = pstatus;
	}

	@Override
	public String toString() {
		return "Product [pid=" + pid + ", pname=" + pname + ", did=" + did + ", image=" + image + ", quantity=" + quantity
				+ ", pstatus=" + pstatus + "]";
	}

	

}
