package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entities.Category;
import com.example.demo.entities.Donor;
import com.example.demo.entities.Login;
import com.example.demo.entities.Product;
import com.example.demo.entities.Receiver;
import com.example.demo.entities.ReceiverRegister;
import com.example.demo.entities.Receiver_Req;
import com.example.demo.entities.SubCategory;
import com.example.demo.services.LoginService;
import com.example.demo.services.ReceiverApprovedService;
import com.example.demo.services.ReceiverRegisterService;


@CrossOrigin(origins = "http://localhost:3000")
@RestController
public class ReceiverApprovedController {
	@Autowired
	ReceiverApprovedService raservice;
	@Autowired
	LoginService sservice;
	@Autowired
	ReceiverRegisterService rservice;
	
	
	
	
	
	
	
	@GetMapping("/approve")
	public Receiver save(@RequestParam("reqid")int  reqid)
	{ 
		Receiver r1 = null;
		 Receiver_Req rr = rservice.getOne(reqid);
	    int n =  rservice.updateStatus(reqid);
	    if(n==1)
	    {
	    	Login l = new Login(rr.getUid(),rr.getPwd(),"receiver");
	    	Login l1= sservice.save(l);
	    	if(l1 != null)
	    	{
	    		Receiver r = new Receiver(rr, l1);
	    		r1 = raservice.saved(r);
	    	}
	    }
	    return r1;
	    
	}
	
	
		
	
	
		
	}
	     
	     
	     
	    
	

