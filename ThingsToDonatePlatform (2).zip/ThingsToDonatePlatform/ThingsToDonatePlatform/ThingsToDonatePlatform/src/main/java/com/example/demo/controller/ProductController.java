package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entities.Donor;
import com.example.demo.entities.DonorRegister;
import com.example.demo.entities.Login;
import com.example.demo.entities.Product;
import com.example.demo.entities.ProductData;
import com.example.demo.entities.ProductRequirement;
import com.example.demo.entities.Receiver;
import com.example.demo.entities.Receiver_Req;
import com.example.demo.entities.SocialWork;
import com.example.demo.services.DonorService;
import com.example.demo.services.LoginService;
import com.example.demo.services.ProductServices;
import com.example.demo.services.ReceiverApprovedService;


@CrossOrigin(origins = "http://localhost:3000")
@RestController
public class ProductController {
	
	


	@Autowired
 ReceiverApprovedService rService;
	

		@Autowired
	 ProductServices pService;
		
		
		@Autowired
		 DonorService dservice;
		@Autowired
		 LoginService lservice;
//all product
		
	@GetMapping("/products")
	public List<Product> getAllProduct(	){
		return pService.getAllProduct();
		
		
		
	}
	
	//
	@GetMapping("/getproduct/{pid}")  
	private Product getProduct(@PathVariable("pid") int pid)   
	{  
	return pService.getProductById(pid);  
	}  
	//delete
	@DeleteMapping("/deleteproduct/{pid}")
	private void deleteProduct(@PathVariable("pid") int pid)   
     { 
		pService.deleteProduct(pid);  
      }  
	//post details			
	@PostMapping("/saveproducts")
	public Product save(@RequestBody ProductData p) {
		int uno = 0;
		Login l=lservice.getOne(uno); 
		
		Donor d=new Donor(p.getDid(),l);
		Product s=new Product (d,p.getPname(),p.getImage(),p.getQuantity(),p.getPstatus());
		
		return pService.save(s);
	 
	}
	
	
	//update
	
	@PutMapping("/updateproducts")
	public Product updateProduct(@RequestBody Product  product) {
	pService.updateProduct(product);
	return product;
	}
	
	@GetMapping("/getBydid")
	public List<Product> getByid(@RequestParam("did")int  pid)
	{
		int uno = 0;
		Login l=lservice.getOne(uno); 
		// reqid=0;
		//Receiver_Req rr=rservice.getOne(reqid);
		
		Donor r = new Donor(pid,l);
		return pService.getAllProduct(r);
	}	

}
