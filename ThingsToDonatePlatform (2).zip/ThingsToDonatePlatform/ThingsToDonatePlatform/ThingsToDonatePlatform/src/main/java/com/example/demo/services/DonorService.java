package com.example.demo.services;

import java.util.List;
import java.util.NoSuchElementException;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entities.Category;
import com.example.demo.entities.Donor;
import com.example.demo.entities.DonorRegister;
import com.example.demo.entities.Login;
import com.example.demo.repositories.DonorRepository;

@Service
public class DonorService {

	
	/*@Autowired
	DonorRegisterRepository lrepo;

	public String register(String did, String fname, String lname, String dob, String email, String pwd, String address,
			String profession, String contactno) {
		return lrepo.register(did, fname,lname,dob,email,pwd,address,profession,contactno);
	}*/
	
	@Autowired
	DonorRepository srepo;
	
	/*public  List<Donor> getAll()
	{
		return srepo.findAll();
	}
	*/
	public  Donor save(Donor d)
	{
		 return srepo.save(d);
	}
	
	/*public Donor getOne(String did)
	{
		Optional<Donor> stu = srepo.findById(did);
		Donor s = null;
		try
		{
			s = stu.get();
		}
		catch(NoSuchElementException e)
		{
			s=null;
		}
		return s;
	
	}
	/*public List<Student> getFromPune()
	{
		return srepo.getFromPune();
	}
	
	public List<Student> getByCities(String city)
	{
		return srepo.getByCities(city);
	}*/

	public String register(String did, String fname, String lname, String dob, String email, String pwd, String address,
			String profession, String contactno) {
		// TODO Auto-generated method stub
		return null;
	}

	public String registerdonor(String did, String fname, String lname, String dob, String email, String pwd,
			String address, String profession, String contactno) {
		// TODO Auto-generated method stub
		return null;
	}

	public Donor getOne(int pid) {
		// TODO Auto-generated method stub
		return srepo.getOne(pid);
	}

	public  List<Donor> getAllDonor()
	{
		return srepo.findAll();
	}

	
	
}

