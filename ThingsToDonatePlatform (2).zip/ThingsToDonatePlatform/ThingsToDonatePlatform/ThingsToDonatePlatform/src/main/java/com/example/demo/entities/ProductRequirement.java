package com.example.demo.entities;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;


	@Entity
	@Table(name="productrequirement")
	public class ProductRequirement {
		@Id
		@GeneratedValue(strategy = GenerationType.IDENTITY)
		int prid;
		@Column
		String pname;
		@ManyToOne
		@JoinColumn(name="sid")
		SubCategory sid;
		@OneToOne
		@JoinColumn(name="rid")
		Receiver rid;
		@Column
		String description;
		public ProductRequirement() {
			super();
			// TODO Auto-generated constructor stub
		}
		/*public ProductRequirement(int prid, String pname, SubCategory sid, Receiver rid, String description) {
			super();
			this.prid = prid;
			this.pname = pname;
			this.sid = sid;
			this.rid = rid;
			this.description = description;
		}*/
		public ProductRequirement(String pname, SubCategory sid, Receiver rid, String description) {
			this.pname = pname;
			this.sid = sid;
			this.rid = rid;
			this.description = description;
		}
		public int getPrid() {
			return prid;
		}
		public void setPrid(int prid) {
			this.prid = prid;
		}
		public String getPname() {
			return pname;
		}
		public void setPname(String pname) {
			this.pname = pname;
		}
		public SubCategory getSid() {
			return sid;
		}
		public void setSid(SubCategory sid) {
			this.sid = sid;
		}
		public Receiver getRid() {
			return rid;
		}
		public void setRid(Receiver rid) {
			this.rid = rid;
		}
		public String getDescription() {
			return description;
		}
		public void setDescription(String description) {
			this.description = description;
		}
		
	
		
}

