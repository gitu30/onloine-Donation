package com.example.demo.services;

import java.util.List;
import java.util.NoSuchElementException;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.example.demo.entities.Category;
import com.example.demo.entities.Receiver;
import com.example.demo.entities.Receiver_Req;

import com.example.demo.repositories.ReceiverRegisterRepository;

@Service
public class ReceiverRegisterService {
	
	/*@Autowired
	DonorRegisterRepository lrepo;

	public String register(String did, String fname, String lname, String dob, String email, String pwd, String address,
			String profession, String contactno) {
		return lrepo.register(did, fname,lname,dob,email,pwd,address,profession,contactno);
	}*/
	@Autowired
	ReceiverRegisterRepository srepo;
	
	/*public  List<Donor> getAll()
	{
		return srepo.findAll();
	}
	*/
/*	public  Receiver save(Receiver r)
	{
		 return srepo.save(r);
	}
	*/
	public  Receiver_Req save(Receiver_Req rt)
	{
		 return srepo.save(rt);
	}
	
	
	public int updateStatus(int reqid)
	{
		return srepo.updateStatus(reqid);
	}
	
	/*public Donor getOne(String did)
	{
		Optional<Donor> stu = srepo.findById(did);
		Donor s = null;
		try
		{
			s = stu.get();
		}
		catch(NoSuchElementException e)
		{
			s=null;
		}
		return s;
	
	}
	/*public List<Student> getFromPune()
	{
		return srepo.getFromPune();
	}
	
	public List<Student> getByCities(String city)
	{
		return srepo.getByCities(city);
	}*/

	public String register(int rid, String rname, String uniqueid, String email, String pwd, String address,
			String requeststatus, String contactno) {
		// TODO Auto-generated method stub
		return null;
	}
	

	public String registerreceiver(int rid, String rname, String uniqueid, String email, String pwd, String address,
			String requeststatus, String contactno) {
		// TODO Auto-generated method stub
		return null;
	}

	

//	public List<Receiver_Req> getAll() {
//
//		
//			return srepo.findAll();
//		
//	}
	
	public List<Receiver_Req> getFromrequeststatus()
	{
		return srepo.getFromrequeststatus();
	}

	public Receiver_Req getOne(int reqid)
	{
		Optional<Receiver_Req> oc = srepo.findById(reqid);
		Receiver_Req c = null;
		try
		{
			c = oc.get();
		}
		catch(NoSuchElementException e)
		{
			c=null;
		}
		return c;
		
		
		
	}
	
}

	